<footer class="bg-white border-t mt-8">
    <div class="px-6 py-4">
        <p class="text-center text-sm text-gray-500">
            &copy; {{ date('Y') }} {{ config('app.name', 'Cipta Imaji') }}. Admin Panel v1.0
        </p>
    </div>
</footer>